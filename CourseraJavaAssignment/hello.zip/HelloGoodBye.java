import edu.princeton.cs.algs4.StdOut;

public class HelloGoodBye{
	public static void main(String args[]){
		StdOut.println("Hello "+args[0]+" "+args[1]);
		StdOut.println("GoodBye "+args[1]+" "+args[0]);
	}
}
